# UFO Saucer: DayZ mod (flies, seats 4)

Made for DayZ 1.28+ (checked against the 1.30 script source). There are no dependencies (no CF or Expansion needed).

## What's in here

| Folder | What it is |
|---|---|
| `P_drive/UFO_Saucer/` | The mod source. Copy this folder to your **P:\\** drive and pack it into a PBO. |
| `@UFO_Saucer/` | The finished mod folder. Your packed `UFO_Saucer.pbo` goes in `Addons/`. |
| `ServerFiles/` | `types.xml` / `events.xml` entries plus a test spawn snippet for `init.c`. |
| `SourceTextures/` | PNG sources for the textures. They're optional because ready-made `.paa` files are already in the mod. |

### The model (`data/ufo_saucer.p3d`, MLOD, opens in Object Builder)
- **Resolution LOD 0**: your Tripo mesh scaled to about 9.8 m wide and 2.9 m tall (17.7k tris). It has a `camo` selection so you can retexture it with `hiddenSelections`.
- **Shadow Volume 0**: a closed convex hull.
- **Geometry**: 4 convex quadrant parts with a total mass of 2,500 kg and `autocenter = 0`.
- **View Geometry / Fire Geometry**: the same 4 quadrants, named `seat_driver` (front left), `seat_codriver` (front right), `seat_cargo1` (rear left) and `seat_cargo2` (rear right). Wherever you look at the hull, you get the seat for that quarter.
- **View Geometry crew proxies**: `crewDriver`, `crewCoDriver`, `crewCargo1`, `crewCargo2`. These point at the tiny `data/proxies/crew.p3d` (written in the proxy name without the `.p3d` extension, as DayZ expects).
- **Memory**: get-in points `pos_*` and `pos_*_dir`, placed about 6 m out around the rim, plus wheel-hub points (needed by the car simulation, but no wheels are used) and the damage-zone points.

### Textures
The PBR set was converted to DayZ's Super shader format:
- `_co` comes from the basecolor.
- `_nohq` is the normal map with green flipped (OpenGL to DirectX).
- `_smdi` is built from metallic and roughness.
- The ambient-shadow (`_as`) stage uses a built-in solid-white texture instead of a file.

## Build (DayZ Tools)
> **Use a fresh PBO.** Delete any old `UFO_Saucer.pbo` from every `Addons` folder (server **and** client) before you copy the new one in. After packing, open the PBO (or check the build log): `data\ufo_saucer.p3d` must start with `ODOL`. If it starts with `MLOD`, Binarize didn't run and you need to repack.

1. Mount the P: drive (DayZ Tools → Workdrive → Mount).
2. Copy `P_drive/UFO_Saucer` to `P:\UFO_Saucer`.
3. In **Addon Builder**:
   - Source directory: `P:\UFO_Saucer`
   - Destination: `...\UFO_Saucer_DayZ_Mod\@UFO_Saucer\Addons`
   - Options → Addon prefix: `UFO_Saucer`
   - Turn **Binarize** on so the model is converted using `model.cfg`. Under "List of files to copy directly", add: `*.paa;*.rvmat;*.ogg;*.xml;*.c`
   - Click **Pack**. If it fails, open Addon Builder's log (or `P:\temp\*.log`). Model errors name the LOD and selection involved.
4. (Optional) Sign the PBO with DS Utils if your server uses `verifySignatures`.

## Install
- **Server**: put `@UFO_Saucer` in the server folder and add `-mod=@UFO_Saucer` (or append it to your existing `-mod=` list). Add the `types.xml` entry, and the `events.xml` / `cfgeventspawns.xml` entries if you want it to spawn naturally.
- **Clients**: need the same `@UFO_Saucer` loaded (Workshop upload or manual).
- **Quick test**: use the `init.c` snippet (it spawns one in front of you), or spawn `UFO_Saucer` with COT or another admin tool. In offline DayZDiag you can spawn it from the debug menu.

## Flying
| Key | Action |
|---|---|
| F (vehicle action) | Start / stop engine |
| W / S | Forward / backward |
| A / D | Turn |
| **Space** | Ascend |
| **C** | Descend |

You can rebind Space and C under Options → Controls → **UFO Saucer**.

- With no input, the UFO **hovers in place**. It leans into movement and turns, then levels itself.
- Descent slows automatically near the ground for a soft touchdown.
- **Engine off in the air:** it sinks no faster than 8 m/s instead of falling.
- **Pilot jumps out with the engine on:** it slowly sinks, lands and shuts down by itself.
- No fuel, battery, plugs, radiator, wheels or doors are needed. It has 10×50 cargo storage.

## Tuning without scripting
Every number is in `config.cpp → class UFOFlight` (speed, climb rate, turn rate, ceiling and so on). If A/D turn the wrong way on your setup, set `invertYaw = 1`.

## How it works (for modders)
- The `UFO_Saucer` class extends `CarScript`. That gives it DayZ's crew seats, get in/out and switch-seat actions, and the 1.28+ networked vehicle simulation with client prediction and server reconciliation.
- W/S/A/D are read from the car's own throttle, brake and steering, which are already networked.
- Space/C use custom inputs (`data/inputs.xml`). They are sent to the server inside the vehicle's `PawnMove` (`UFO_SaucerMove.Write/Read`), so the server simulates exactly what the pilot pressed. This is the same pattern Expansion uses for its helicopters on 1.28+.
- The flight model runs in `EOnSimulate` on the server and on the pilot's client. It uses `ApplyForceAt`/`ApplyTorque`: velocity tracking with gravity cancelled, plus a PD controller for self-levelling and yaw rate.

## Things to check in-game / adjust in Object Builder
- **Seat pose:** the crew proxies sit 0.4 m above the floor inside the hull. Players are hidden inside the shell, and the first-person view looks out through it because the shell is single-sided. To change where people sit, move the 4 proxy triangles in View Geometry. To change where they climb out, move the `pos_*` points in the Memory LOD.
- **Normal map looks inverted** (bumps look like dents): flip the green channel of `SourceTextures/ufo_nohq.png` back and rerun `convert_textures.bat`.
- **The speedometer reads 0** because there are no wheels.
- **Sounds:** the engine hum and power up/down sounds are synthesized placeholders in `sounds/`. Swap in your own `.ogg` files with the same names.
