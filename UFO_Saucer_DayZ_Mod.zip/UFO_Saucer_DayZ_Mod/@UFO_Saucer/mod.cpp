name = "UFO Saucer";
author = "";
overview = "A flyable 4-seat UFO. W/S forward/back, A/D turn, Space ascend, C descend.";
action = "";
