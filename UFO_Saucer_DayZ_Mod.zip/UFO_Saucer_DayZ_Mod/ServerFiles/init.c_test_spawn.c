// Quick test: spawn ONE UFO near the first player who joins (remove after testing).
// Paste into mpmissions/<your mission>/init.c inside class CustomMission.

static bool s_UFOTestSpawned = false;

override void InvokeOnConnect(PlayerBase player, PlayerIdentity identity)
{
	super.InvokeOnConnect(player, identity);

	if (s_UFOTestSpawned)
		return;
	s_UFOTestSpawned = true;

	vector pos = player.GetPosition() + player.GetDirection() * 12;
	pos[1] = GetGame().SurfaceY(pos[0], pos[2]);
	GetGame().CreateObjectEx("UFO_Saucer", pos, ECE_PLACE_ON_SURFACE);
}
