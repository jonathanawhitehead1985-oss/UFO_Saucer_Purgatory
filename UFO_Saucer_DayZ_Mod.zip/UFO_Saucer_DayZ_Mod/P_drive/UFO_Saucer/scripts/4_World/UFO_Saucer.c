// =====================================================================================
//  UFO Saucer - flying 4-seat vehicle
//
//  Built on CarScript so it gets DayZ's crew seats, get in/out actions and the 1.28+
//  networked vehicle simulation (client prediction + server reconciliation).
//
//  Controls (driver):
//    W / S  .... forward / backward            (car throttle / brake)
//    A / D  .... turn left / right             (car steering)
//    Space  .... ascend                         (UAUFOAscend, rebindable)
//    C      .... descend                        (UAUFODescend, rebindable)
//    Start/stop the engine with the normal vehicle action.
//
//  The vertical input is not a vanilla car input, so it is sent to the server inside the
//  vehicle's PawnMove (UFO_SaucerMove) - the same mechanism vanilla uses for throttle and
//  steering - so the server simulates exactly what the pilot pressed.
// =====================================================================================

class UFO_SaucerMove : CarScriptMove
{
	float m_Lift;

	protected override event void Write(PawnMoveWriter ctx, PawnMove prev)
	{
		super.Write(ctx, prev);
		ctx.Write(m_Lift);
	}

	protected override event void Read(PawnMoveReader ctx, PawnMove prev)
	{
		super.Read(ctx, prev);
		ctx.Read(m_Lift);
	}

	protected override event int EstimateMaximumSize()
	{
		return super.EstimateMaximumSize() + 4;
	}
};

//! Tunables, read once per vehicle type from CfgVehicles <type> UFOFlight
class UFO_FlightConfig
{
	float MaxSpeed = 45;
	float ReverseSpeed = 15;
	float ClimbSpeed = 12;
	float DescendSpeed = 14;
	float YawRate = 75;
	float Response = 1.4;
	float MaxAccelH = 14;
	float MaxAccelV = 12;
	float MaxAltitudeATL = 800;
	float MaxTiltDeg = 10;
	float LevelStiffness = 6;
	float LevelDamping = 4;
	float YawResponse = 4;
	float LandingSlowdownHeight = 6;
	float LandingSpeed = 2.5;
	float EngineOffMaxFall = 8;
	float NoPilotDescend = 3;
	float NoPilotShutdownTime = 4;
	bool InfiniteFuel = true;
	float ContactDamageCoef = 0.015;
	bool InvertYaw = false;

	protected static ref map<string, ref UFO_FlightConfig> s_Cache;

	static UFO_FlightConfig Get(string type)
	{
		if (!s_Cache)
			s_Cache = new map<string, ref UFO_FlightConfig>;

		UFO_FlightConfig cfg;
		if (s_Cache.Find(type, cfg))
			return cfg;

		cfg = new UFO_FlightConfig();
		cfg.Load(type);
		s_Cache.Insert(type, cfg);
		return cfg;
	}

	protected float Read(string path, string name, float def)
	{
		string full = path + name;
		if (g_Game.ConfigIsExisting(full))
			return g_Game.ConfigGetFloat(full);
		return def;
	}

	void Load(string type)
	{
		string p = "CfgVehicles " + type + " UFOFlight ";
		MaxSpeed              = Read(p, "maxSpeed", MaxSpeed);
		ReverseSpeed          = Read(p, "reverseSpeed", ReverseSpeed);
		ClimbSpeed            = Read(p, "climbSpeed", ClimbSpeed);
		DescendSpeed          = Read(p, "descendSpeed", DescendSpeed);
		YawRate               = Read(p, "yawRate", YawRate);
		Response              = Read(p, "response", Response);
		MaxAccelH             = Read(p, "maxAccelH", MaxAccelH);
		MaxAccelV             = Read(p, "maxAccelV", MaxAccelV);
		MaxAltitudeATL        = Read(p, "maxAltitudeATL", MaxAltitudeATL);
		MaxTiltDeg            = Read(p, "maxTiltDeg", MaxTiltDeg);
		LevelStiffness        = Read(p, "levelStiffness", LevelStiffness);
		LevelDamping          = Read(p, "levelDamping", LevelDamping);
		YawResponse           = Read(p, "yawResponse", YawResponse);
		LandingSlowdownHeight = Read(p, "landingSlowdownHeight", LandingSlowdownHeight);
		LandingSpeed          = Read(p, "landingSpeed", LandingSpeed);
		EngineOffMaxFall      = Read(p, "engineOffMaxFall", EngineOffMaxFall);
		NoPilotDescend        = Read(p, "noPilotDescend", NoPilotDescend);
		NoPilotShutdownTime   = Read(p, "noPilotShutdownTime", NoPilotShutdownTime);
		InfiniteFuel          = Read(p, "infiniteFuel", 1) > 0.5;
		ContactDamageCoef     = Read(p, "contactDamageCoef", ContactDamageCoef);
		InvertYaw             = Read(p, "invertYaw", 0) > 0.5;

		LandingSlowdownHeight = Math.Max(LandingSlowdownHeight, 0.1);
		MaxSpeed = Math.Max(MaxSpeed, 1);
	}
};

class UFO_Saucer : CarScript
{
	static const string INPUT_ASCEND  = "UAUFOAscend";
	static const string INPUT_DESCEND = "UAUFODescend";

	protected ref UFO_FlightConfig m_Flight;
	protected float m_Lift;          //!< vertical input used by the simulation (-1..1)
	protected float m_LocalLift;     //!< vertical input read from this client's keyboard
	protected float m_NoPilotTimer;  //!< server: time spent resting with engine on and no pilot
	protected vector m_Gravity;
	protected bool m_GravityKnown;
	protected EffectSound m_HumSound;

	void UFO_Saucer()
	{
		m_EngineStartOK      = "UFO_PowerUp_SoundSet";
		m_EngineStartBattery = "UFO_PowerDown_SoundSet";
		m_EngineStartPlug    = "UFO_PowerDown_SoundSet";
		m_EngineStartFuel    = "UFO_PowerDown_SoundSet";
		m_EngineStop         = "UFO_PowerDown_SoundSet";
		m_EngineStopFuel     = "UFO_PowerDown_SoundSet";

		SetEnginePos("0 1 0");
	}

	void ~UFO_Saucer()
	{
		StopHum();
	}

	override void EEInit()
	{
		super.EEInit();

		m_dmgContactCoef = GetFlight().ContactDamageCoef;

		if (g_Game.IsServer())
			FillUpCarFluids();
	}

	override void EEOnCECreate()
	{
		super.EEOnCECreate();
		FillUpCarFluids();
	}

	override void OnDebugSpawn()
	{
		FillUpCarFluids();
	}

	UFO_FlightConfig GetFlight()
	{
		if (!m_Flight)
			m_Flight = UFO_FlightConfig.Get(GetType());
		return m_Flight;
	}

	protected vector GetGravityVector()
	{
		if (!m_GravityKnown)
		{
			m_Gravity = "0 -9.81 0";
			IEntity world = g_Game.GetWorldEntity();
			if (world)
			{
				vector g = dGetGravity(world);
				if (g.Length() > 1.0)
					m_Gravity = g;
			}
			m_GravityKnown = true;
		}
		return m_Gravity;
	}

	// ---------------------------------------------------------------- no car parts needed
	override bool IsVitalSparkPlug()          { return false; }
	override bool IsVitalGlowPlug()           { return false; }
	override bool IsVitalFuelTank()           { return false; }
	override bool IsVitalRadiator()           { return false; }
	override bool IsVitalEngineBelt()         { return false; }
	override bool NeedElectricitySourceDevice() { return false; }

	override int CheckOperationalRequirements()
	{
		int state = ECarOperationalState.OK;

		if (IsDamageDestroyed() || GetHealthLevel("Engine") >= GameConstants.STATE_RUINED)
			state |= ECarOperationalState.RUINED;

		if (GetFluidFraction(CarFluid.FUEL) <= 0)
			state |= ECarOperationalState.NO_FUEL;

		return state;
	}

	//! Only flipped when actually upside down (there are no wheels to test)
	protected override bool DetectFlipped(VehicleFlippedContext ctx)
	{
		return vector.Dot(GetDirectionUp(), vector.Up) < 0.2;
	}

	// ---------------------------------------------------------------- seats
	override int GetAnimInstance()
	{
		return VehicleAnimInstances.SEDAN;
	}

	override int GetSeatAnimationType(int posIdx)
	{
		switch (posIdx)
		{
			case 0: return DayZPlayerConstants.VEHICLESEAT_DRIVER;
			case 1: return DayZPlayerConstants.VEHICLESEAT_CODRIVER;
			case 2: return DayZPlayerConstants.VEHICLESEAT_PASSENGER_L;
			case 3: return DayZPlayerConstants.VEHICLESEAT_PASSENGER_R;
		}
		return 0;
	}

	override float GetTransportCameraDistance()
	{
		return 13.0;
	}

	override vector GetTransportCameraOffset()
	{
		return "0 2.5 0";
	}

	//! No doors: every seat is always reachable
	override bool CrewCanGetThrough(int posIdx)
	{
		return true;
	}

	override bool CanReachSeatFromSeat(int currentSeat, int nextSeat)
	{
		return true;
	}

	override bool CanReachDoorsFromSeat(string pDoorsSelection, int pCurrentSeat)
	{
		return true;
	}

	//! The hull is ~10 m wide: allow boarding from anywhere around the rim
	override bool CanReachSeatFromDoors(string pSeatSelection, vector pFromPos, float pDistance = 1.0)
	{
		vector centre = GetPosition();
		centre[1] = 0;
		pFromPos[1] = 0;
		return vector.Distance(centre, pFromPos) <= 8.0;
	}

	override void SetActions()
	{
		// no doors / horn / pushing - just boarding (in-vehicle actions come from the player)
		AddAction(ActionGetInTransport);
	}

	//! Vanilla stops the engine when the driver leaves in gear; the UFO instead auto-lands
	override void OnDriverExit(Human player)
	{
	}

	// ---------------------------------------------------------------- input + networking
	protected override event typename GetMoveType()
	{
		return UFO_SaucerMove;
	}

	protected bool IsLocalPilot()
	{
		if (g_Game.IsDedicatedServer())
			return false;

		Human driver = CrewDriver();
		return driver && driver == g_Game.GetPlayer() && driver.IsControllingVehicle();
	}

	protected float ReadLocalLift()
	{
		UAInputAPI api = GetUApi();
		if (!api)
			return 0;

		UAInput ascend = api.GetInputByName(INPUT_ASCEND);
		UAInput descend = api.GetInputByName(INPUT_DESCEND);

		float lift = 0;
		if (ascend)
			lift += ascend.LocalValue();
		if (descend)
			lift -= descend.LocalValue();

		return Math.Clamp(lift, -1.0, 1.0);
	}

	override void OnInput(float dt)
	{
		super.OnInput(dt);

		if (IsLocalPilot())
		{
			m_LocalLift = ReadLocalLift();
			m_Lift = m_LocalLift;
		}
		else
		{
			m_LocalLift = 0;
		}
	}

	//! Owner client: pack this step's input
	protected override event void ObtainMove(PawnMove pMove)
	{
		super.ObtainMove(pMove);

		UFO_SaucerMove move = UFO_SaucerMove.Cast(pMove);
		if (move)
			move.m_Lift = m_LocalLift;
	}

	//! Server: apply the pilot's input before simulating the step
	protected override event void ConsumeMove(PawnMove pMove)
	{
		super.ConsumeMove(pMove);

		UFO_SaucerMove move = UFO_SaucerMove.Cast(pMove);
		if (move)
			m_Lift = move.m_Lift;
	}

	//! Owner client: re-apply recorded input when replaying after a server correction
	protected override event bool ReplayMove(PawnMove pMove)
	{
		if (!super.ReplayMove(pMove))
			return false;

		UFO_SaucerMove move = UFO_SaucerMove.Cast(pMove);
		if (move)
			m_Lift = move.m_Lift;

		return true;
	}

	// ---------------------------------------------------------------- flight model
	override void EOnSimulate(IEntity other, float dt)
	{
		super.EOnSimulate(other, dt);

		// runs on the server and on the pilot's client (prediction); never on proxies
		if (IsProxy())
			return;

		SimulateFlight(dt);
	}

	protected void SimulateFlight(float dt)
	{
		if (dt <= 0)
			return;

		float mass = dBodyGetMass(this);
		if (mass <= 0)
			return;

		UFO_FlightConfig cfg = GetFlight();

		vector mat[4];
		dBodyGetWorldTransform(this, mat);

		vector pos = mat[3];
		vector vel = GetVelocity(this);
		vector g = GetGravityVector();

		float ground = g_Game.SurfaceY(pos[0], pos[2]);
		if (ground < 0)
			ground = 0; // sea level
		float heightATL = pos[1] - ground;

		if (!EngineIsOn())
		{
			// residual anti-gravity: a dead engine sinks, it doesn't drop like a rock
			if (vel[1] < -cfg.EngineOffMaxFall)
			{
				float up = -g[1] + 3.0 * (-cfg.EngineOffMaxFall - vel[1]);
				ApplyForce(Vector(0, mass * up, 0));
			}
			return;
		}

		Human driver = CrewDriver();
		bool hasPilot = driver && driver.IsControllingVehicle();

		float fwdIn = 0;
		float yawIn = 0;
		float liftIn = 0;
		if (hasPilot)
		{
			fwdIn = Math.Clamp(GetThrottle() - GetBrake(), -1.0, 1.0);
			yawIn = Math.Clamp(GetSteering(), -1.0, 1.0);
			if (cfg.InvertYaw)
				yawIn = -yawIn;
			liftIn = Math.Clamp(m_Lift, -1.0, 1.0);
		}

		// heading on the horizontal plane
		vector fwd = mat[2];
		fwd[1] = 0;
		if (fwd.Normalize() < 0.001)
			fwd = "0 0 1";
		vector right = mat[0];
		right[1] = 0;
		if (right.Normalize() < 0.001)
			right = "1 0 0";

		// ---- linear: steer velocity toward a target velocity, gravity cancelled
		vector target;
		if (fwdIn >= 0)
			target = fwd * (fwdIn * cfg.MaxSpeed);
		else
			target = fwd * (fwdIn * cfg.ReverseSpeed);

		float vy;
		if (hasPilot)
		{
			if (liftIn > 0)
				vy = liftIn * cfg.ClimbSpeed;
			else
				vy = liftIn * cfg.DescendSpeed;
		}
		else
		{
			vy = -cfg.NoPilotDescend;
		}

		if (heightATL > cfg.MaxAltitudeATL)
		{
			if (vy > 0)
				vy = 0;
			if (heightATL > cfg.MaxAltitudeATL + 20)
				vy = -2;
		}

		if (vy < 0 && heightATL < cfg.LandingSlowdownHeight)
		{
			float k = Math.Clamp(heightATL / cfg.LandingSlowdownHeight, 0, 1);
			float maxSink = Math.Lerp(cfg.LandingSpeed, Math.Max(cfg.DescendSpeed, cfg.LandingSpeed), k);
			vy = Math.Max(vy, -maxSink);
		}
		target[1] = vy;

		vector acc = (target - vel) * cfg.Response;
		vector accH = Vector(acc[0], 0, acc[2]);
		float aH = accH.Length();
		if (aH > cfg.MaxAccelH)
			accH = accH * (cfg.MaxAccelH / aH);
		float aV = Math.Clamp(acc[1], -cfg.MaxAccelV, cfg.MaxAccelV);

		// push through the centre of mass so thrust doesn't pitch the hull
		ApplyForceAt(GetCenterOfMassWS(mat), Vector(accH[0], aV - g[1], accH[2]) * mass);

		// ---- angular: hold level (with a little lean), follow yaw-rate input
		vector axR = mat[0];
		vector axU = mat[1];
		vector axF = mat[2];

		vector w = dBodyGetAngularVelocity(this);
		vector wl = Vector(vector.Dot(w, axR), vector.Dot(w, axU), vector.Dot(w, axF));

		float tilt = cfg.MaxTiltDeg * Math.DEG2RAD;
		float speedFrac = Math.Clamp(Math.AbsFloat(vector.Dot(vel, fwd)) / cfg.MaxSpeed, 0.2, 1.0);
		float pitch = fwdIn * tilt * 0.8;
		float roll = yawIn * tilt * speedFrac;

		vector upTarget = vector.Up + fwd * Math.Tan(pitch) + right * Math.Tan(roll);
		upTarget.Normalize();

		vector err = axU * upTarget; // cross product: rotation axis that brings up -> upTarget
		vector errL = Vector(vector.Dot(err, axR), vector.Dot(err, axU), vector.Dot(err, axF));

		float yawTarget = yawIn * cfg.YawRate * Math.DEG2RAD;

		vector invI = dBodyGetInvInertiaDiagLocal(this);
		vector inertia = Vector(SafeInv(invI[0], mass), SafeInv(invI[1], mass), SafeInv(invI[2], mass));

		float tx = inertia[0] * (cfg.LevelStiffness * errL[0] - cfg.LevelDamping * wl[0]);
		float ty = inertia[1] * (cfg.YawResponse * (yawTarget - wl[1]));
		float tz = inertia[2] * (cfg.LevelStiffness * errL[2] - cfg.LevelDamping * wl[2]);

		ApplyTorque(axR * tx + axU * ty + axF * tz);

		if (!dBodyIsActive(this))
			dBodyActive(this, ActiveState.ACTIVE);
	}

	protected vector GetCenterOfMassWS(vector mat[4])
	{
		vector c = dBodyGetCenterOfMass(this);
		if (c.Length() > 50.0)
			return c; // already world space
		return mat[3] + mat[0] * c[0] + mat[1] * c[1] + mat[2] * c[2];
	}

	protected float SafeInv(float v, float mass)
	{
		if (v > 0.000001)
			return 1.0 / v;
		return mass * 8.0; // rough fallback (≈ m * r^2 for a ~3 m radius)
	}

	// ---------------------------------------------------------------- per-frame bookkeeping
	override void OnUpdate(float dt)
	{
		super.OnUpdate(dt);

		if (g_Game.IsServer())
			ServerUpdate(dt);

		// a sleeping body is not simulated, so make sure a running UFO is awake
		if (EngineIsOn() && !IsProxy() && !dBodyIsActive(this))
			dBodyActive(this, ActiveState.ACTIVE);

		if (!g_Game.IsDedicatedServer())
			UpdateHum();
	}

	protected void ServerUpdate(float dt)
	{
		UFO_FlightConfig cfg = GetFlight();

		if (cfg.InfiniteFuel && GetFluidFraction(CarFluid.FUEL) < 0.9)
			Fill(CarFluid.FUEL, GetFluidCapacity(CarFluid.FUEL));

		// pilot left with the engine running: it sinks (see SimulateFlight), then powers down once resting
		Human driver = CrewDriver();
		bool hasPilot = driver && driver.IsControllingVehicle();
		if (EngineIsOn() && !hasPilot && GetVelocity(this).Length() < 0.3)
		{
			m_NoPilotTimer += dt;
			if (m_NoPilotTimer >= cfg.NoPilotShutdownTime)
			{
				m_NoPilotTimer = 0;
				EngineStop();
			}
		}
		else
		{
			m_NoPilotTimer = 0;
		}
	}

	// ---------------------------------------------------------------- hum loop
	protected void UpdateHum()
	{
		bool on = EngineIsOn();
		if (on && !m_HumSound)
		{
			m_HumSound = SEffectManager.PlaySoundOnObject("UFO_Hum_SoundSet", this, 1.0, 1.0, true);
			if (m_HumSound)
				m_HumSound.SetSoundAutodestroy(true);
		}
		else if (!on && m_HumSound)
		{
			StopHum();
		}
	}

	protected void StopHum()
	{
		if (m_HumSound)
		{
			m_HumSound.SoundStop();
			m_HumSound = null;
		}
	}
};
