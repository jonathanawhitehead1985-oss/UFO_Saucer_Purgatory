class CfgPatches
{
	class UFO_Saucer
	{
		units[] = {"UFO_Saucer"};
		weapons[] = {};
		requiredVersion = 0.1;
		requiredAddons[] =
		{
			"DZ_Data",
			"DZ_Sounds_Effects",
			"DZ_Vehicles_Wheeled"
		};
	};
};

class CfgMods
{
	class UFO_Saucer
	{
		dir = "UFO_Saucer";
		name = "UFO Saucer";
		credits = "";
		author = "";
		version = "1.0";
		type = "mod";
		inputs = "UFO_Saucer/data/inputs.xml";
		dependencies[] = {"World"};

		class defs
		{
			class worldScriptModule
			{
				value = "";
				files[] = {"UFO_Saucer/scripts/4_World"};
			};
		};
	};
};

class CfgSoundShaders
{
	class UFO_Hum_SoundShader
	{
		samples[] = {{"UFO_Saucer\sounds\ufo_hum", 1}};
		volume = 0.9;
		range = 300;
	};
	class UFO_PowerUp_SoundShader
	{
		samples[] = {{"UFO_Saucer\sounds\ufo_powerup", 1}};
		volume = 1.0;
		range = 200;
	};
	class UFO_PowerDown_SoundShader
	{
		samples[] = {{"UFO_Saucer\sounds\ufo_powerdown", 1}};
		volume = 1.0;
		range = 200;
	};
};

class CfgSoundSets
{
	class UFO_Base_SoundSet
	{
		sound3DProcessingType = "Vehicle_Ext_3DProcessingType";
		distanceFilter = "softVehiclesDistanceFreqAttenuationFilter";
		volumeCurve = "vehicleEngineAttenuationCurve";
		volumeFactor = 1;
		frequencyFactor = 1;
		spatial = 1;
		doppler = 0;
		loop = 0;
	};
	class UFO_Hum_SoundSet: UFO_Base_SoundSet
	{
		soundShaders[] = {"UFO_Hum_SoundShader"};
		loop = 1;
	};
	class UFO_PowerUp_SoundSet: UFO_Base_SoundSet
	{
		soundShaders[] = {"UFO_PowerUp_SoundShader"};
	};
	class UFO_PowerDown_SoundSet: UFO_Base_SoundSet
	{
		soundShaders[] = {"UFO_PowerDown_SoundShader"};
	};
};

class CfgVehicles
{
	class Car;
	class CarScript;
	class SimulationModule;
	class Axles;
	class Front;
	class Rear;
	class Crew;
	class Driver;
	class CoDriver;

	class UFO_Saucer: CarScript
	{
		scope = 2;
		displayName = "UFO Saucer";
		descriptionShort = "An unidentified flying object. Seats four. Space = ascend, C = descend.";
		model = "\UFO_Saucer\data\ufo_saucer.p3d";

		// no car parts needed: no battery, plugs, radiator, wheels or doors
		attachments[] = {};
		fuelCapacity = 100;
		fuelConsumption = 0.1;

		// CarScript reserves hidden-selection slots 0-8 for lights, so "camo" goes in slot 9
		hiddenSelections[] = {"light_1_1","light_2_1","light_brake_1_2","light_brake_2_2","light_reverse_1_2","light_reverse_2_2","light_1_2","light_2_2","light_dashboard","camo"};
		hiddenSelectionsTextures[] = {"","","","","","","","","","UFO_Saucer\data\ufo_co.paa"};
		hiddenSelectionsMaterials[] = {"","","","","","","","","","UFO_Saucer\data\ufo.rvmat"};

		// ------------------------------------------------------------------
		// Flight tuning (read by scripts/4_World/UFO_Saucer.c). Edit freely.
		// ------------------------------------------------------------------
		class UFOFlight
		{
			maxSpeed = 45;              // m/s forward (≈160 km/h)
			reverseSpeed = 15;          // m/s backward
			climbSpeed = 12;            // m/s up (Space)
			descendSpeed = 14;          // m/s down (C)
			yawRate = 75;               // deg/s turn rate (A/D)
			response = 1.4;             // how quickly velocity follows input (1/s)
			maxAccelH = 14;             // m/s^2 horizontal accel limit
			maxAccelV = 12;             // m/s^2 vertical accel limit
			maxAltitudeATL = 800;       // ceiling, metres above terrain
			maxTiltDeg = 10;            // visual lean when flying/turning
			levelStiffness = 6;         // self-levelling spring
			levelDamping = 4;           // self-levelling damper
			yawResponse = 4;            // how quickly turn rate follows input
			landingSlowdownHeight = 6;  // start slowing descent below this height (m)
			landingSpeed = 2.5;         // touchdown speed (m/s)
			engineOffMaxFall = 8;       // engine off in the air: fall no faster than this (m/s)
			noPilotDescend = 3;         // pilot left with engine on: sink at this speed and auto-land
			noPilotShutdownTime = 4;    // seconds resting without a pilot before engine shuts off
			infiniteFuel = 1;           // 1 = never needs fuel
			contactDamageCoef = 0.015;  // vanilla cars use 0.058; lower = tougher hull
			invertYaw = 0;              // set 1 if A/D turn the wrong way
		};

		class Crew: Crew
		{
			class Driver: Driver
			{
				actionSel = "seat_driver";
				proxyPos = "crewDriver";
				getInPos = "pos_driver";
				getInDir = "pos_driver_dir";
				isDriver = 1;
			};
			class CoDriver: CoDriver
			{
				actionSel = "seat_codriver";
				proxyPos = "crewCoDriver";
				getInPos = "pos_codriver";
				getInDir = "pos_codriver_dir";
			};
			class Cargo1
			{
				actionSel = "seat_cargo1";
				proxyPos = "crewCargo1";
				getInPos = "pos_cargo1";
				getInDir = "pos_cargo1_dir";
			};
			class Cargo2
			{
				actionSel = "seat_cargo2";
				proxyPos = "crewCargo2";
				getInPos = "pos_cargo2";
				getInDir = "pos_cargo2_dir";
			};
		};

		class SimulationModule: SimulationModule
		{
			// The car drivetrain is only used to read W/S/A/D. The script does the flying.
			class Steering
			{
				maxSteeringAngle = 30;
				increaseSpeed[] = {0, 240, 300, 240};
				decreaseSpeed[] = {0, 240, 300, 240};
				centeringSpeed[] = {0, 300, 300, 300};
			};
			class Throttle
			{
				reactionTime = 0.15;
				defaultThrust = 1.0;
				gentleThrust = 0.5;
				turboCoef = 1.0;
				gentleCoef = 0.5;
			};
			class Brake
			{
				pressureBySpeed[] = {0, 1.0, 300, 1.0};
				reactionTime = 0.15;
				driverless = 0;
			};
			class Aerodynamics
			{
				frontalArea = 6.0;
				dragCoefficient = 0.05;
			};
			drive = "DRIVE_RWD";
			class Engine
			{
				// torque falls to zero at 6000 rpm and the redline is 9000,
				// so a free-revving "engine" can never take over-rev damage
				torqueCurve[] = {500, 0, 1000, 60, 3000, 80, 5000, 40, 6000, 0};
				inertia = 0.2;
				frictionTorque = 40;
				rollingFriction = 0.5;
				viscousFriction = 0.5;
				rpmIdle = 800;
				rpmMin = 900;
				rpmClutch = 1200;
				rpmRedline = 9000;
			};
			class Clutch
			{
				maxTorqueTransfer = 200;
				uncoupleTime = 0.2;
				coupleTime = 0.2;
			};
			class Gearbox
			{
				type = "GEARBOX_MANUAL";
				reverse = 3.5;
				ratios[] = {3.5, 2.0};
			};
			class Axles: Axles
			{
				class Front: Front
				{
					maxBrakeTorque = 500;
					wheelHubMass = 5;
					wheelHubRadius = 0.15;
					class Suspension
					{
						stiffness = 40000;
						compression = 2000;
						damping = 5000;
						travelMaxUp = 0.05;
						travelMaxDown = 0.05;
					};
				};
				class Rear: Rear
				{
					maxBrakeTorque = 500;
					maxHandbrakeTorque = 500;
					wheelHubMass = 5;
					wheelHubRadius = 0.15;
					class Differential
					{
						ratio = 4.0;
						type = "DIFFERENTIAL_OPEN";
					};
					class Suspension
					{
						stiffness = 40000;
						compression = 2000;
						damping = 5000;
						travelMaxUp = 0.05;
						travelMaxDown = 0.05;
					};
				};
			};
		};

		class Cargo
		{
			itemsCargoSize[] = {10, 50};
			allowOwnedCargoManipulation = 1;
			openable = 0;
		};

		class Sounds
		{
			thrust = 0.6;
			thrustTurbo = 1;
			thrustGentle = 0.3;
			thrustSmoothCoef = 0.1;
			camposSmoothCoef = 0.03;
			soundSetsFilter[] = {};
			soundSetsInt[] = {};
		};

		class DamageSystem
		{
			class GlobalHealth
			{
				class Health
				{
					hitpoints = 6000;
					healthLevels[] =
					{
						{1.0, {"UFO_Saucer\data\ufo.rvmat"}},
						{0.7, {"UFO_Saucer\data\ufo.rvmat"}},
						{0.5, {"UFO_Saucer\data\ufo.rvmat"}},
						{0.3, {"UFO_Saucer\data\ufo.rvmat"}},
						{0.0, {"UFO_Saucer\data\ufo.rvmat"}}
					};
				};
			};
			class DamageZones
			{
				class Engine
				{
					class Health
					{
						hitpoints = 4000;
						transferToGlobalCoef = 1;
						healthLevels[] =
						{
							{1.0, {}},
							{0.7, {}},
							{0.5, {}},
							{0.3, {}},
							{0.0, {}}
						};
					};
					fatalInjuryCoef = -1;
					componentNames[] = {"dmgzone_body"};
					memoryPoints[] = {"dmgzone_engine"};
					inventorySlots[] = {};
				};
				class FuelTank
				{
					class Health
					{
						hitpoints = 4000;
						transferToGlobalCoef = 0;
						healthLevels[] =
						{
							{1.0, {}},
							{0.7, {}},
							{0.5, {}},
							{0.3, {}},
							{0.0, {}}
						};
					};
					fatalInjuryCoef = -1;
					componentNames[] = {};
					memoryPoints[] = {"dmgzone_fueltank"};
					inventorySlots[] = {};
				};
			};
		};
	};
};
