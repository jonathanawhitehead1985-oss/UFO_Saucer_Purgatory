@echo off
REM Optional: regenerate the .paa textures from these PNGs with DayZ Tools.
REM The mod already ships ready-made .paa files; only run this if you edit the PNGs.
REM Adjust the path below if DayZ Tools is installed somewhere else.
set IMG2PAA="C:\Program Files (x86)\Steam\steamapps\common\DayZ Tools\Bin\ImageToPAA\ImageToPAA.exe"
set OUT=P:\UFO_Saucer\data
for %%F in (ufo_co ufo_nohq ufo_smdi) do (
  %IMG2PAA% "%~dp0%%F.png" "%OUT%\%%F.paa"
)
echo Done.
pause
